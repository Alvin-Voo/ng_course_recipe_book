import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Ingredient } from '../../shared/ingredient.model';
import { ShoppingListService } from '../shopping-list.service';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit, OnDestroy {
  @ViewChild('f') myForm:NgForm;
  editItemSubs: Subscription;
  editMode = false;
  editItemIndex: number;
  editItemIngredient: Ingredient;
  constructor(private shoppingListService : ShoppingListService) { }

  ngOnInit() {
    this.editItemSubs = this.shoppingListService.editItem.subscribe(
      (index: number)=>{
        this.editMode = true;
        this.editItemIndex = index;
        this.editItemIngredient = this.shoppingListService.getIngredient(index);

        this.myForm.setValue({
          'name' : this.editItemIngredient.name,
          'amount' : this.editItemIngredient.amount
        }
        )
      }
    );
  }

  onDelete(){
    this.shoppingListService.removeIngredient(this.editItemIndex);
    this.onClear();
  }

  onClear(){
    this.myForm.reset();
    this.editMode = false;
  }

  onSubmitForm(){
    // console.log(myForm);
    if(!this.editMode)
      this.shoppingListService.addIngredient(new Ingredient(this.myForm.value.name,this.myForm.value.amount));
    else
      this.shoppingListService.updateIngredient(this.editItemIndex, new Ingredient(this.myForm.value.name,this.myForm.value.amount));

    this.myForm.reset();
    this.editMode = false;
  }

  ngOnDestroy(){
    this.editItemSubs.unsubscribe();
  }
}
