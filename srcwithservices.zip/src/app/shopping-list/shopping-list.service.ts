import {Ingredient} from '../shared/ingredient.model';
import { Subject } from 'rxjs/Subject';

export class ShoppingListService{
  ingredientChanged = new Subject<Ingredient[]>();
  editItem = new Subject<number>();
  private ingredients: Ingredient[] = [
    new Ingredient('garlic',14),
    new Ingredient('basil leaves',5)
  ];

  getIngredients() {
    return this.ingredients.slice();
  }

  getIngredient(index:number){
    return this.ingredients[index];
  }

  addIngredient(ingredient:Ingredient){
    this.ingredients.push(ingredient);
    this.ingredientChanged.next(this.ingredients.slice());
  }

  removeIngredient(index:number){
    // this.ingredients.pop();
    this.ingredients.splice(index,1);
    this.ingredientChanged.next(this.ingredients.slice());
  }

  getIngredientsCount():number{
    return this.ingredients.length;
  }

  addIngredients(ingredients:Ingredient[]){
    //update ingredients data
    this.ingredients.push(...ingredients);
    //emit ingredient changed signal so shopping list will update
    this.ingredientChanged.next(this.ingredients.slice());
  }

  updateIngredient(index:number, ingredient:Ingredient){
    this.ingredients[index] = ingredient;
    this.ingredientChanged.next(this.ingredients.slice());
  }
}
