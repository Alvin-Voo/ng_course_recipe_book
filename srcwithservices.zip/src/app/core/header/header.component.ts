import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RecipeService } from '../../recipes/recipe.service';
import { AuthService } from '../../auth/auth.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  isCollapsed = false;


  constructor(private recipeService : RecipeService, private authService: AuthService, private router: Router) {
    this.isCollapsed = true;
  }

  ngOnInit() {

  }

  onSave(){
    this.recipeService.storeRecipes();
  }

  onFetch(){
    this.recipeService.fetchRecipes();
  }

  onSignOut(){
    this.authService.logOut();
    this.router.navigate(['/signin']);
  }

  isAuthenticated(){
    return this.authService.isAuthenticated();
  }
}
