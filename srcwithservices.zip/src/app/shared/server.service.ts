import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpRequest } from '@angular/common/http';
import { Recipe } from '../recipes/recipe.model';

@Injectable()
export class ServerService {

  constructor(private httpClient: HttpClient) { }

  storeRecipes(recipes: Recipe[]){
    //can also consider using the sdk firebase.database interface
    // return this.httpClient.put('https://ng-recipe-book-ca30c.firebaseio.com/recipes.json',
    // recipes,
    // {observe:'response',
    // responseType:'json',
    // params: new HttpParams().set('auth',this.authService.getToken())});

  //   const httpRequest = new HttpRequest('PUT','https://ng-recipe-book-ca30c.firebaseio.com/recipes.json',
  // recipes,{reportProgress: true, params: new HttpParams().set('auth',this.authService.getToken())});

    //interceptor will handle getting the token
    const httpRequest = new HttpRequest('PUT','https://ng-recipe-book-ca30c.firebaseio.com/recipes.json',
  recipes,{reportProgress: true});

  return this.httpClient.request(httpRequest);
  }

  fetchRecipes(){
    return this.httpClient.get<Recipe[]>('https://ng-recipe-book-ca30c.firebaseio.com/recipes.json',
    {observe:'body', responseType:'json'});
  }
}
