export class Ingredient{
  constructor(public name:string, public amount:number){} //<-- shortcut for typescript to initialize this class based on the public assessor
}
