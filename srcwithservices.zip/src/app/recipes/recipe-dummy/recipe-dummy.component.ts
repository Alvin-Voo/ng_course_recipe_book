import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-dummy',
  templateUrl: './recipe-dummy.component.html',
  styleUrls: ['./recipe-dummy.component.css']
})
export class RecipeDummyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
