import {Injectable} from '@angular/core';
import {Recipe} from './recipe.model';
import {Ingredient} from '../shared/ingredient.model';
import {ShoppingListService} from '../shopping-list/shopping-list.service';
import { Subject } from 'rxjs/Subject';
import { ServerService } from '../shared/server.service';

@Injectable()
export class RecipeService{
  recipeChanged = new Subject<Recipe[]>();
  private recipes: Recipe[] = [
    new Recipe('recipe 1',
    'something mushy',
    "https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Pieminister_beef_steak_ale_pie_%282%29.jpg/607px-Pieminister_beef_steak_ale_pie_%282%29.jpg",
  [
    new Ingredient('steak',1),
    new Ingredient('pie',2)
  ]),
    new Recipe('recipe 2',
    'something fishy',
    "https://images.pexels.com/photos/8758/food-dinner-lemon-rice.jpg?w=940&h=650&auto=compress&cs=tinysrgb",
  [
    new Ingredient('fish',1),
    new Ingredient('lemon',12)
  ])
  ]; //an array of custom Recipe models

  constructor(private shoppingListService:ShoppingListService,
    private serverService: ServerService){}

  getRecipes(){
    return this.recipes.slice();
  }

  toShoppingList(ingredients:Ingredient[]){
    this.shoppingListService.addIngredients(ingredients);
  }

  getRecipe(index: number){
    return this.recipes[index];
  }

  addRecipe(recipe: Recipe):number{
    this.recipes.push(recipe);
    this.recipeChanged.next(this.recipes.slice());
    return this.recipes.length;
  }

  updateRecipe(index: number, recipe:Recipe){
    this.recipes[index] = recipe;
    this.recipeChanged.next(this.recipes.slice());
  }

  deleteRecipe(index: number){
    this.recipes.splice(index,1);
    this.recipeChanged.next(this.recipes.slice());
  }

  storeRecipes(){
    this.serverService.storeRecipes(this.recipes.slice())
    .subscribe(
      (response)=>{console.log(response)},
      (error)=>{console.log(error)}
    )
  }

  fetchRecipes(){
    this.serverService.fetchRecipes()
    .subscribe(
      (recipes: Recipe[])=>{
        console.log(recipes);//seems like in observables n promise the console log data is a bit tricky
        recipes.forEach(
          (recipe: Recipe)=>{
            //create empty ingredients array for those which doesnt have any
            if (!recipe.ingredients) recipe.ingredients = new Array<Ingredient>();
          }
        )
        this.recipes = recipes
        this.recipeChanged.next(this.recipes.slice());
      },
      (error)=>{console.log(error)}
    )
  }

}
