import { Component, OnInit } from '@angular/core';
import { Recipe } from '../recipe.model';
import { RecipeService } from '../recipe.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-recipe-detail',
  templateUrl: './recipe-detail.component.html',
  styleUrls: ['./recipe-detail.component.css']
})
export class RecipeDetailComponent implements OnInit {
  currentRecipeNameSelected :Recipe;
  index : number;
  recipesSub: Subscription;
  constructor(private recipeService: RecipeService,
    private route: ActivatedRoute,
    private router: Router) {

  }

  ngOnInit() {

    this.route.params.subscribe(
      (params: Params) => {
        this.index = Number(params['index']);
        this.currentRecipeNameSelected = this.recipeService.getRecipe(this.index);
      }
    )

    this.recipesSub = this.recipeService.recipeChanged.subscribe(
      (recipes: Recipe[]) => {
        this.currentRecipeNameSelected = recipes[this.index];
      }
    )
  }

  toShoppingList(){
    console.log("shoppig list caled");
    this.recipeService.toShoppingList(this.currentRecipeNameSelected.ingredients);
  }

  onEditRecipe(){
    this.router.navigate(['edit'],{relativeTo:this.route});
  }

  onDeleteRecipe(){
    this.recipeService.deleteRecipe(this.index);
    this.router.navigate(['/recipes']);
  }

}
