import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  errorMessage = '';
  constructor(private authService: AuthService) { }

  ngOnInit() {
  }

  onSignUp(myForm: NgForm){
    const email = myForm.value.email;
    const password = myForm.value.password;
    this.errorMessage = '';
    this.authService.signupUser(email, password)
    .catch(
      (error)=>{
        this.errorMessage = error.message;
      }
    );

  }

}
