import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  errorMessage = "";

  constructor(private authService: AuthService) { }

  ngOnInit() {
  }

  onSignIn(myForm: NgForm){
    const email = myForm.value.email;
    const password = myForm.value.password;
    this.errorMessage='';
    this.authService.signinUser(email, password)
    .catch(
      (error)=>{
        this.errorMessage = error.message;
      }
    );
  }
}
