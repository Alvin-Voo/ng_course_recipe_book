import * as firebase from 'firebase';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class AuthService {
  private token: string;

  constructor(private router: Router) { }

  signupUser(email: string, password: string): Promise<any>{
    console.log('singup called');
    return firebase.auth().createUserWithEmailAndPassword(email,password);
  }

  signinUser(email: string, password: string): Promise<any>{
    console.log('singin called');

    return firebase.auth().signInWithEmailAndPassword(email,password)
    .then(
      response => {
        firebase.auth().currentUser.getIdToken()
        .then(
          (token: string) => this.token = token
        )
        //redirect user once successful
        this.router.navigate(['/']);
      }
    );
  }

  getToken(): string{
    firebase.auth().currentUser.getIdToken()
    .then(
      (token: string) => this.token = token
    );
    return this.token;
  }

  isAuthenticated(): boolean{
    return this.token != null;
  }

  logOut(){
    firebase.auth().signOut();
    this.token = null;
  }
}
